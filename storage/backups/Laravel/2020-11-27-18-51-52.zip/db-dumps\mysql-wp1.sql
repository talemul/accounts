
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admin_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_menu` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) NOT NULL DEFAULT '0',
  `order` int(11) NOT NULL DEFAULT '0',
  `title` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `uri` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permission` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_menu` WRITE;
/*!40000 ALTER TABLE `admin_menu` DISABLE KEYS */;
INSERT INTO `admin_menu` VALUES (1,0,1,'Dashboard','fa-bar-chart','/',NULL,NULL,NULL),(2,0,2,'Admin','fa-tasks','',NULL,NULL,NULL),(3,2,3,'Users','fa-users','auth/users',NULL,NULL,NULL),(4,2,4,'Roles','fa-user','auth/roles',NULL,NULL,NULL),(5,2,5,'Permission','fa-ban','auth/permissions',NULL,NULL,NULL),(6,2,6,'Menu','fa-bars','auth/menu',NULL,NULL,NULL),(7,2,7,'Operation log','fa-history','auth/logs',NULL,NULL,NULL),(23,0,8,'Helpers','fas fa-cogs','',NULL,'2020-11-20 13:53:27','2020-11-20 14:44:08'),(24,23,9,'Scaffold','fas fa-keyboard','helpers/scaffold',NULL,'2020-11-20 13:53:27','2020-11-20 14:44:08'),(25,23,10,'Database terminal','fas fa-database','helpers/terminal/database',NULL,'2020-11-20 13:53:27','2020-11-20 14:44:08'),(26,23,11,'Laravel artisan','fas fa-terminal','helpers/terminal/artisan',NULL,'2020-11-20 13:53:27','2020-11-20 14:44:08'),(27,23,12,'Routes','fas fa-list-alt','helpers/routes',NULL,'2020-11-20 13:53:27','2020-11-20 14:44:08'),(28,0,13,'Backup','fa-copy','backup',NULL,'2020-11-20 13:54:45','2020-11-20 14:44:08'),(34,0,14,'Log viewer','fa-database','logs',NULL,'2020-11-20 13:56:02','2020-11-20 14:44:08'),(38,0,0,'BuildingInformation','fa-bars','building_information',NULL,'2020-11-27 10:06:32','2020-11-27 10:06:32'),(39,0,0,'UnitInformation','fa-bars','unit_information',NULL,'2020-11-27 10:06:54','2020-11-27 10:06:54'),(40,0,0,'ShiftInformation','fa-bars','shift_information',NULL,'2020-11-27 10:07:28','2020-11-27 10:07:28'),(41,0,0,'SectionInformation','fa-bars','section_information',NULL,'2020-11-27 10:08:03','2020-11-27 10:08:03'),(42,0,0,'ReligionInformation','fa-bars','religion_information',NULL,'2020-11-27 10:08:21','2020-11-27 10:08:21'),(43,0,0,'DistrictInformation','fa-bars','district_information',NULL,'2020-11-27 10:08:40','2020-11-27 10:08:40'),(44,0,0,'DesignationInformation','fa-bars','designation_information',NULL,'2020-11-27 10:08:58','2020-11-27 10:08:58'),(45,0,0,'ProjectInformation','fa-bars','project_information',NULL,'2020-11-27 10:09:21','2020-11-27 10:09:21'),(46,0,0,'DepartmentInformation','fa-bars','department_information',NULL,'2020-11-27 10:09:36','2020-11-27 10:09:36');
/*!40000 ALTER TABLE `admin_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_operation_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_operation_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `method` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ip` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `input` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `admin_operation_log_user_id_index` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=255 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_operation_log` WRITE;
/*!40000 ALTER TABLE `admin_operation_log` DISABLE KEYS */;
INSERT INTO `admin_operation_log` VALUES (1,1,'admin','GET','127.0.0.1','[]','2020-11-20 13:29:44','2020-11-20 13:29:44'),(2,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 13:30:26','2020-11-20 13:30:26'),(3,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 13:30:44','2020-11-20 13:30:44'),(4,1,'admin/auth/permissions','GET','127.0.0.1','[]','2020-11-20 14:40:41','2020-11-20 14:40:41'),(5,1,'admin/helpers/scaffold','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:40:57','2020-11-20 14:40:57'),(6,1,'admin/helpers/terminal/database','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:41:01','2020-11-20 14:41:01'),(7,1,'admin/helpers/terminal/artisan','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:41:03','2020-11-20 14:41:03'),(8,1,'admin/helpers/routes','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:41:04','2020-11-20 14:41:04'),(9,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:41:40','2020-11-20 14:41:40'),(10,1,'admin/helpers/routes','GET','127.0.0.1','[]','2020-11-20 14:41:41','2020-11-20 14:41:41'),(11,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:41:58','2020-11-20 14:41:58'),(12,1,'admin/helpers/routes','GET','127.0.0.1','[]','2020-11-20 14:41:58','2020-11-20 14:41:58'),(13,1,'admin/logs','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:42:00','2020-11-20 14:42:00'),(14,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:17','2020-11-20 14:43:17'),(15,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:26','2020-11-20 14:43:26'),(16,1,'admin/auth/menu/35','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:43:39','2020-11-20 14:43:39'),(17,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:39','2020-11-20 14:43:39'),(18,1,'admin/auth/menu/29','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:43:43','2020-11-20 14:43:43'),(19,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:44','2020-11-20 14:43:44'),(20,1,'admin/auth/menu/18','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:43:51','2020-11-20 14:43:51'),(21,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:52','2020-11-20 14:43:52'),(22,1,'admin/auth/menu/8','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:43:57','2020-11-20 14:43:57'),(23,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:43:57','2020-11-20 14:43:57'),(24,1,'admin/auth/menu/13','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:44:02','2020-11-20 14:44:02'),(25,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:44:02','2020-11-20 14:44:02'),(26,1,'admin/auth/menu','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_order\":\"[{\\\"id\\\":1},{\\\"id\\\":2,\\\"children\\\":[{\\\"id\\\":3},{\\\"id\\\":4},{\\\"id\\\":5},{\\\"id\\\":6},{\\\"id\\\":7}]},{\\\"id\\\":23,\\\"children\\\":[{\\\"id\\\":24},{\\\"id\\\":25},{\\\"id\\\":26},{\\\"id\\\":27}]},{\\\"id\\\":28},{\\\"id\\\":34}]\"}','2020-11-20 14:44:08','2020-11-20 14:44:08'),(27,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:44:09','2020-11-20 14:44:09'),(28,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-20 14:44:10','2020-11-20 14:44:10'),(29,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:44:18','2020-11-20 14:44:18'),(30,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-20 14:44:18','2020-11-20 14:44:18'),(31,1,'admin/logs','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:44:20','2020-11-20 14:44:20'),(32,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:53:00','2020-11-20 14:53:00'),(33,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 14:53:00','2020-11-20 14:53:00'),(34,1,'admin/logs','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:53:18','2020-11-20 14:53:18'),(35,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:58:07','2020-11-20 14:58:07'),(36,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 14:58:08','2020-11-20 14:58:08'),(37,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 14:59:27','2020-11-20 14:59:27'),(38,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:59:35','2020-11-20 14:59:35'),(39,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 14:59:46','2020-11-20 14:59:46'),(40,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 14:59:57','2020-11-20 14:59:57'),(41,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:00:47','2020-11-20 15:00:47'),(42,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:01:37','2020-11-20 15:01:37'),(43,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:06:14','2020-11-20 15:06:14'),(44,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 15:06:52','2020-11-20 15:06:52'),(45,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 15:06:57','2020-11-20 15:06:57'),(46,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 15:08:16','2020-11-20 15:08:16'),(47,1,'admin/logs','GET','127.0.0.1','[]','2020-11-20 15:08:19','2020-11-20 15:08:19'),(48,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:08:23','2020-11-20 15:08:23'),(49,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:08:24','2020-11-20 15:08:24'),(50,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:08:57','2020-11-20 15:08:57'),(51,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:10:05','2020-11-20 15:10:05'),(52,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:12:11','2020-11-20 15:12:11'),(53,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:12','2020-11-20 15:12:12'),(54,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:12','2020-11-20 15:12:12'),(55,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:13','2020-11-20 15:12:13'),(56,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:14','2020-11-20 15:12:14'),(57,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:14','2020-11-20 15:12:14'),(58,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:15','2020-11-20 15:12:15'),(59,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:16','2020-11-20 15:12:16'),(60,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:16','2020-11-20 15:12:16'),(61,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:17','2020-11-20 15:12:17'),(62,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:17','2020-11-20 15:12:17'),(63,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:18','2020-11-20 15:12:18'),(64,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:19','2020-11-20 15:12:19'),(65,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:20','2020-11-20 15:12:20'),(66,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:20','2020-11-20 15:12:20'),(67,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:21','2020-11-20 15:12:21'),(68,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:21','2020-11-20 15:12:21'),(69,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:22','2020-11-20 15:12:22'),(70,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:23','2020-11-20 15:12:23'),(71,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:24','2020-11-20 15:12:24'),(72,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:24','2020-11-20 15:12:24'),(73,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:12:25','2020-11-20 15:12:25'),(74,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:12:46','2020-11-20 15:12:46'),(75,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:18:58','2020-11-20 15:18:58'),(76,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:20:34','2020-11-20 15:20:34'),(77,1,'admin','GET','127.0.0.1','[]','2020-11-20 15:20:34','2020-11-20 15:20:34'),(78,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:20:35','2020-11-20 15:20:35'),(79,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:35','2020-11-20 15:20:35'),(80,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:35','2020-11-20 15:20:35'),(81,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:36','2020-11-20 15:20:36'),(82,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:36','2020-11-20 15:20:36'),(83,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:36','2020-11-20 15:20:36'),(84,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:36','2020-11-20 15:20:36'),(85,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:36','2020-11-20 15:20:36'),(86,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:37','2020-11-20 15:20:37'),(87,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:37','2020-11-20 15:20:37'),(88,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:37','2020-11-20 15:20:37'),(89,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:38','2020-11-20 15:20:38'),(90,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:38','2020-11-20 15:20:38'),(91,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:38','2020-11-20 15:20:38'),(92,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:38','2020-11-20 15:20:38'),(93,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:38','2020-11-20 15:20:38'),(94,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:39','2020-11-20 15:20:39'),(95,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:39','2020-11-20 15:20:39'),(96,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:39','2020-11-20 15:20:39'),(97,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:39','2020-11-20 15:20:39'),(98,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:40','2020-11-20 15:20:40'),(99,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:20:40','2020-11-20 15:20:40'),(100,1,'admin/backup','GET','127.0.0.1','[]','2020-11-20 15:21:13','2020-11-20 15:21:13'),(101,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:21:21','2020-11-20 15:21:21'),(102,1,'admin/helpers/scaffold','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:41:58','2020-11-20 15:41:58'),(103,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"test_table\",\"model_name\":\"App\\\\Models\\\\\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\\",\"create\":[\"migration\",\"model\",\"controller\",\"migrate\"],\"fields\":[{\"name\":\"column_name\",\"type\":\"json\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"name\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"soft_deletes\":\"on\",\"primary_key\":\"id\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:43:26','2020-11-20 15:43:26'),(104,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-20 15:43:26','2020-11-20 15:43:26'),(105,1,'admin/logs','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:43:44','2020-11-20 15:43:44'),(106,1,'admin/helpers/scaffold','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 15:52:45','2020-11-20 15:52:45'),(107,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"banglas\",\"model_name\":\"App\\\\Models\\\\\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\\",\"create\":[\"migration\",\"model\",\"controller\",\"migrate\"],\"fields\":[{\"name\":\"Name\",\"type\":\"string\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"primary_key\":\"id\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:52:55','2020-11-20 15:52:55'),(108,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-20 15:52:55','2020-11-20 15:52:55'),(109,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"test_table\",\"model_name\":\"App\\\\Models\\\\TestTable\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\TestTableController\",\"create\":[\"migration\",\"model\",\"controller\",\"migrate\"],\"fields\":[{\"name\":\"name\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"column_name\",\"type\":\"json\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"soft_deletes\":\"on\",\"primary_key\":\"id\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 15:54:33','2020-11-20 15:54:33'),(110,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-20 15:54:33','2020-11-20 15:54:33'),(111,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:01:06','2020-11-20 16:01:06'),(112,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:01:54','2020-11-20 16:01:54'),(113,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:02:00','2020-11-20 16:02:00'),(114,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-20 16:02:28','2020-11-20 16:02:28'),(115,1,'admin/test_table','POST','127.0.0.1','{\"name\":\"Talemul Islam\",\"column_name\":{\"new_1\":{\"key\":\"sdf\",\"value\":\"ewr\",\"desc\":null,\"_remove_\":\"0\"},\"new_2\":{\"key\":null,\"value\":\"ewr\",\"desc\":null,\"_remove_\":\"0\"},\"new_3\":{\"key\":null,\"value\":\"ewt\",\"desc\":\"ewt\",\"_remove_\":\"0\"}},\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/test_table\"}','2020-11-20 16:02:47','2020-11-20 16:02:47'),(116,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:02:47','2020-11-20 16:02:47'),(117,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:02:54','2020-11-20 16:02:54'),(118,1,'admin/test_table','POST','127.0.0.1','{\"name\":\"Bangla\",\"column_name\":{\"new_1\":{\"key\":\"fds\",\"value\":\"sdf\",\"desc\":\"fds\",\"_remove_\":\"0\"},\"new_2\":{\"key\":\"sdf\",\"value\":\"dsf\",\"desc\":\"dsf\",\"_remove_\":\"0\"},\"new_3\":{\"key\":\"sfd\",\"value\":\"dsf\",\"desc\":\"dsf\",\"_remove_\":\"0\"}},\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/test_table\"}','2020-11-20 16:03:10','2020-11-20 16:03:10'),(119,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:03:10','2020-11-20 16:03:10'),(120,1,'admin/test_table/2/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:03:30','2020-11-20 16:03:30'),(121,1,'admin/test_table/2','PUT','127.0.0.1','{\"name\":\"Bangla\",\"column_name\":[{\"key\":\"fds\",\"value\":\"sdf\",\"desc\":\"fds\",\"_remove_\":\"0\"},{\"key\":\"sdf\",\"value\":\"dsf\",\"desc\":\"dsf\",\"_remove_\":\"1\"},{\"key\":\"sfd\",\"value\":\"dsf\",\"desc\":\"dsf\",\"_remove_\":\"0\"}],\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/test_table\"}','2020-11-20 16:03:38','2020-11-20 16:03:38'),(122,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:03:38','2020-11-20 16:03:38'),(123,1,'admin/test_table/2','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:03:45','2020-11-20 16:03:45'),(124,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:03:46','2020-11-20 16:03:46'),(125,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:04:45','2020-11-20 16:04:45'),(126,1,'admin/test_table/1','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:04:51','2020-11-20 16:04:51'),(127,1,'admin/test_table','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:04:54','2020-11-20 16:04:54'),(128,1,'admin/_handle_action_','POST','127.0.0.1','{\"_key\":\"1\",\"_model\":\"App_Models_TestTable\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_action\":\"Encore_Admin_Grid_Actions_Delete\",\"_input\":\"true\"}','2020-11-20 16:04:59','2020-11-20 16:04:59'),(129,1,'admin/test_table','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:04:59','2020-11-20 16:04:59'),(130,1,'admin/test_table/2','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 16:05:08','2020-11-20 16:05:08'),(131,1,'admin/test_table','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:05:08','2020-11-20 16:05:08'),(132,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:05:15','2020-11-20 16:05:15'),(133,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:05:41','2020-11-20 16:05:41'),(134,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:05:53','2020-11-20 16:05:53'),(135,1,'admin/test_table/2/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:10:20','2020-11-20 16:10:20'),(136,1,'admin/test_table','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:10:30','2020-11-20 16:10:30'),(137,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:10:33','2020-11-20 16:10:33'),(138,1,'admin/test_table','POST','127.0.0.1','{\"name\":\"Talemul Islam\",\"column_name\":{\"new_1\":{\"key\":\"fee\",\"value\":\"jnj\",\"desc\":\"jnjn\",\"_remove_\":\"0\"},\"new_2\":{\"key\":null,\"value\":\"jnnj\",\"desc\":\"njn\",\"_remove_\":\"0\"},\"new_3\":{\"key\":\"jn\",\"value\":\"jn\",\"desc\":\"k,\",\"_remove_\":\"0\"},\"new_4\":{\"key\":\"m,\",\"value\":\"m,\",\"desc\":\"mm,\",\"_remove_\":\"0\"}},\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/test_table\"}','2020-11-20 16:11:03','2020-11-20 16:11:03'),(139,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:11:04','2020-11-20 16:11:04'),(140,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:11:46','2020-11-20 16:11:46'),(141,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-20 16:14:07','2020-11-20 16:14:07'),(142,1,'admin/test_table','POST','127.0.0.1','{\"name\":null,\"column_name\":{\"new_1\":{\"key\":\"532\",\"selectbox\":\"val\",\"value\":\"324\",\"desc\":\"32\",\"_remove_\":\"0\"},\"new_2\":{\"key\":\"325\",\"selectbox\":\"2\",\"value\":\"325\",\"desc\":\"352\",\"_remove_\":\"0\"},\"new_3\":{\"key\":\"325\",\"selectbox\":\"1\",\"value\":\"325\",\"desc\":\"325\",\"_remove_\":\"0\"}},\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/test_table\"}','2020-11-20 16:14:34','2020-11-20 16:14:34'),(143,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-20 16:14:35','2020-11-20 16:14:35'),(144,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:14:51','2020-11-20 16:14:51'),(145,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-20 16:15:11','2020-11-20 16:15:11'),(146,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-20 16:18:24','2020-11-20 16:18:24'),(147,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:19:02','2020-11-20 16:19:02'),(148,1,'admin/auth/menu/37','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 16:19:07','2020-11-20 16:19:07'),(149,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:19:07','2020-11-20 16:19:07'),(150,1,'admin/auth/menu/36','DELETE','127.0.0.1','{\"_method\":\"delete\",\"_token\":\"j4K2pJEoDNvndzRfA1WVUFRAZZAtGYXzZk3jcLcd\"}','2020-11-20 16:19:12','2020-11-20 16:19:12'),(151,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:19:12','2020-11-20 16:19:12'),(152,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-20 16:20:05','2020-11-20 16:20:05'),(153,1,'admin/helpers/scaffold','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-20 16:21:38','2020-11-20 16:21:38'),(154,1,'admin','GET','127.0.0.1','[]','2020-11-23 11:09:28','2020-11-23 11:09:28'),(155,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:09:38','2020-11-23 11:09:38'),(156,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:10:45','2020-11-23 11:10:45'),(157,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:10:55','2020-11-23 11:10:55'),(158,1,'admin/auth/roles/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:11:00','2020-11-23 11:11:00'),(159,1,'admin/auth/roles','POST','127.0.0.1','{\"slug\":\"backup\",\"name\":\"backup\",\"permissions\":[\"11\",null],\"_token\":\"WL4SRG9ZEZenSiVvGjsaFgnosHBVP46Xz0EEWm3a\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/auth\\/roles\"}','2020-11-23 11:11:31','2020-11-23 11:11:31'),(160,1,'admin/auth/roles','GET','127.0.0.1','[]','2020-11-23 11:11:31','2020-11-23 11:11:31'),(161,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:11:35','2020-11-23 11:11:35'),(162,1,'admin/auth/users/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:11:37','2020-11-23 11:11:37'),(163,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:12:20','2020-11-23 11:12:20'),(164,1,'admin/backup/run','POST','127.0.0.1','{\"_token\":\"WL4SRG9ZEZenSiVvGjsaFgnosHBVP46Xz0EEWm3a\"}','2020-11-23 11:12:22','2020-11-23 11:12:22'),(165,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:12:31','2020-11-23 11:12:31'),(166,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-23 11:23:45','2020-11-23 11:23:45'),(167,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-23 11:23:55','2020-11-23 11:23:55'),(168,1,'admin','GET','127.0.0.1','[]','2020-11-25 09:07:40','2020-11-25 09:07:40'),(169,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-25 09:08:01','2020-11-25 09:08:01'),(170,1,'admin/test_table/3/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-25 09:08:12','2020-11-25 09:08:12'),(171,1,'admin/test_table/3/edit','GET','127.0.0.1','[]','2020-11-25 09:37:46','2020-11-25 09:37:46'),(172,1,'admin/test_table','GET','127.0.0.1','[]','2020-11-25 09:39:28','2020-11-25 09:39:28'),(173,1,'admin/test_table/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-25 09:39:31','2020-11-25 09:39:31'),(174,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:40:48','2020-11-25 09:40:48'),(175,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:46:11','2020-11-25 09:46:11'),(176,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:54:39','2020-11-25 09:54:39'),(177,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:54:39','2020-11-25 09:54:39'),(178,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:54:39','2020-11-25 09:54:39'),(179,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:54:40','2020-11-25 09:54:40'),(180,1,'admin/test_table/create','GET','127.0.0.1','[]','2020-11-25 09:54:49','2020-11-25 09:54:49'),(181,1,'admin','GET','127.0.0.1','[]','2020-11-27 09:32:51','2020-11-27 09:32:51'),(182,1,'admin/helpers/scaffold','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 09:33:10','2020-11-27 09:33:10'),(183,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"project_informations\",\"model_name\":\"App\\\\Models\\\\ProjectInformation\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\ProjectInformationController\",\"create\":[\"migration\",\"model\",\"controller\"],\"fields\":[{\"name\":\"description\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"projecr_address\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"address2\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"level\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"soft_deletes\":\"on\",\"primary_key\":\"id\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 09:36:01','2020-11-27 09:36:01'),(184,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-27 09:36:02','2020-11-27 09:36:02'),(185,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"project_informations\",\"model_name\":\"App\\\\Models\\\\ProjectInformation\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\ProjectInformationController\",\"create\":[\"migration\",\"migrate\"],\"fields\":[{\"name\":\"description\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"projecr_address\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"address2\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"level\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"primary_key\":\"id\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 09:42:30','2020-11-27 09:42:30'),(186,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-27 09:42:31','2020-11-27 09:42:31'),(187,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"section_informations\",\"model_name\":\"App\\\\Models\\\\SectionInformation\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\SectionInformationController\",\"create\":[\"migration\",\"model\",\"controller\",\"migrate\"],\"fields\":[{\"name\":\"description\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"others_description\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"level\",\"type\":\"string\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"soft_deletes\":\"on\",\"primary_key\":\"id\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 09:45:57','2020-11-27 09:45:57'),(188,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-27 09:45:58','2020-11-27 09:45:58'),(189,1,'admin/helpers/scaffold','POST','127.0.0.1','{\"table_name\":\"department_informations\",\"model_name\":\"App\\\\Models\\\\DepartmentInformation\",\"controller_name\":\"App\\\\Admin\\\\Controllers\\\\DepartmentInformationController\",\"create\":[\"migration\",\"model\",\"controller\",\"migrate\"],\"fields\":[{\"name\":\"description\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"other_descriptions\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null},{\"name\":\"level\",\"type\":\"string\",\"nullable\":\"on\",\"key\":null,\"default\":null,\"comment\":null}],\"timestamps\":\"on\",\"soft_deletes\":\"on\",\"primary_key\":\"id\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 09:47:35','2020-11-27 09:47:35'),(190,1,'admin/helpers/scaffold','GET','127.0.0.1','[]','2020-11-27 09:47:35','2020-11-27 09:47:35'),(191,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:05:57','2020-11-27 10:05:57'),(192,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"BuildingInformation\",\"icon\":\"fa-bars\",\"uri\":\"building_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:06:32','2020-11-27 10:06:32'),(193,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:06:33','2020-11-27 10:06:33'),(194,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"UnitInformation\",\"icon\":\"fa-bars\",\"uri\":\"unit_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:06:54','2020-11-27 10:06:54'),(195,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:06:55','2020-11-27 10:06:55'),(196,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"ShiftInformation\",\"icon\":\"fa-bars\",\"uri\":\"shift_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:07:28','2020-11-27 10:07:28'),(197,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:07:29','2020-11-27 10:07:29'),(198,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"SectionInformation\",\"icon\":\"fa-bars\",\"uri\":\"section_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:08:03','2020-11-27 10:08:03'),(199,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:08:04','2020-11-27 10:08:04'),(200,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"ReligionInformation\",\"icon\":\"fa-bars\",\"uri\":\"religion_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:08:21','2020-11-27 10:08:21'),(201,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:08:22','2020-11-27 10:08:22'),(202,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"DistrictInformation\",\"icon\":\"fa-bars\",\"uri\":\"district_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:08:40','2020-11-27 10:08:40'),(203,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:08:41','2020-11-27 10:08:41'),(204,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"DesignationInformation\",\"icon\":\"fa-bars\",\"uri\":\"designation_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:08:58','2020-11-27 10:08:58'),(205,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:08:58','2020-11-27 10:08:58'),(206,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"ProjectInformation\",\"icon\":\"fa-bars\",\"uri\":\"project_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:09:21','2020-11-27 10:09:21'),(207,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:09:22','2020-11-27 10:09:22'),(208,1,'admin/auth/menu','POST','127.0.0.1','{\"parent_id\":\"0\",\"title\":\"DepartmentInformation\",\"icon\":\"fa-bars\",\"uri\":\"department_information\",\"roles\":[null],\"permission\":null,\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\"}','2020-11-27 10:09:36','2020-11-27 10:09:36'),(209,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:09:36','2020-11-27 10:09:36'),(210,1,'admin/auth/menu','GET','127.0.0.1','[]','2020-11-27 10:10:25','2020-11-27 10:10:25'),(211,1,'admin/building_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:10:36','2020-11-27 10:10:36'),(212,1,'admin/building_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:09','2020-11-27 10:12:09'),(213,1,'admin/unit_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:11','2020-11-27 10:12:11'),(214,1,'admin/shift_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:13','2020-11-27 10:12:13'),(215,1,'admin/section_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:14','2020-11-27 10:12:14'),(216,1,'admin/religion_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:15','2020-11-27 10:12:15'),(217,1,'admin/religion_information/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:17','2020-11-27 10:12:17'),(218,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:22','2020-11-27 10:12:22'),(219,1,'admin/project_information/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:12:24','2020-11-27 10:12:24'),(220,1,'admin/project_information','POST','127.0.0.1','{\"description\":\"CRM\",\"projecr_address\":\"badda\",\"address2\":\"badda, dhaka\",\"level\":\"1\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/project_information\"}','2020-11-27 10:13:16','2020-11-27 10:13:16'),(221,1,'admin/project_information','GET','127.0.0.1','[]','2020-11-27 10:13:16','2020-11-27 10:13:16'),(222,1,'admin/project_information/1','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:13:22','2020-11-27 10:13:22'),(223,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:13:26','2020-11-27 10:13:26'),(224,1,'admin/project_information/1/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:13:29','2020-11-27 10:13:29'),(225,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:13:33','2020-11-27 10:13:33'),(226,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:14:06','2020-11-27 10:14:06'),(227,1,'admin/project_information','GET','127.0.0.1','[]','2020-11-27 10:17:45','2020-11-27 10:17:45'),(228,1,'admin/project_information/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:18:00','2020-11-27 10:18:00'),(229,1,'admin/project_information','POST','127.0.0.1','{\"name\":\"HRM\",\"description\":\"HRM project\",\"projecr_address\":\"Highway Homes \\u2013 2nd floor KA \\u2013 32\\/6 Shahjadpur, Pragoti Sharoni, Gulshan\",\"address2\":\"Dhaka\",\"level\":\"2\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/project_information\"}','2020-11-27 10:18:49','2020-11-27 10:18:49'),(230,1,'admin/project_information','GET','127.0.0.1','[]','2020-11-27 10:18:49','2020-11-27 10:18:49'),(231,1,'admin/project_information/1/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:18:55','2020-11-27 10:18:55'),(232,1,'admin/project_information/1','PUT','127.0.0.1','{\"name\":\"CRM\",\"description\":\"CRM project\",\"projecr_address\":\"badda\",\"address2\":\"badda, dhaka\",\"level\":\"1\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\",\"_method\":\"PUT\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/project_information\"}','2020-11-27 10:19:05','2020-11-27 10:19:05'),(233,1,'admin/project_information','GET','127.0.0.1','[]','2020-11-27 10:19:05','2020-11-27 10:19:05'),(234,1,'admin/project_information/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:21:54','2020-11-27 10:21:54'),(235,1,'admin/project_information','POST','127.0.0.1','{\"name\":\"Bangladesh Thai\",\"description\":\"Bangladesh Thai\",\"projecr_address\":\"Badda Dhaka\",\"address2\":\"Banani Dhaka\",\"level\":\"1\",\"_token\":\"FuGM6ggFXhbdNbJmO7ScMDItwXQkoyONdpX4v8zr\",\"_previous_\":\"http:\\/\\/localhost:8000\\/admin\\/project_information\"}','2020-11-27 10:22:51','2020-11-27 10:22:51'),(236,1,'admin/project_information','GET','127.0.0.1','[]','2020-11-27 10:22:51','2020-11-27 10:22:51'),(237,1,'admin/project_information/3','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:22:56','2020-11-27 10:22:56'),(238,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:22:58','2020-11-27 10:22:58'),(239,1,'admin/project_information/3/edit','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:23:01','2020-11-27 10:23:01'),(240,1,'admin/project_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:23:04','2020-11-27 10:23:04'),(241,1,'admin/department_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:23:17','2020-11-27 10:23:17'),(242,1,'admin/department_information/create','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:23:19','2020-11-27 10:23:19'),(243,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:23:50','2020-11-27 10:23:50'),(244,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:24:02','2020-11-27 10:24:02'),(245,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:24:05','2020-11-27 10:24:05'),(246,1,'admin/auth/users','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:24:11','2020-11-27 10:24:11'),(247,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:24:19','2020-11-27 10:24:19'),(248,1,'admin','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:24:46','2020-11-27 10:24:46'),(249,1,'admin/building_information','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:25:45','2020-11-27 10:25:45'),(250,1,'admin/auth/permissions','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:26:07','2020-11-27 10:26:07'),(251,1,'admin/auth/roles','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:26:10','2020-11-27 10:26:10'),(252,1,'admin/auth/menu','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:26:27','2020-11-27 10:26:27'),(253,1,'admin/logs','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 10:26:40','2020-11-27 10:26:40'),(254,1,'admin/backup','GET','127.0.0.1','{\"_pjax\":\"#pjax-container\"}','2020-11-27 12:31:21','2020-11-27 12:31:21');
/*!40000 ALTER TABLE `admin_operation_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `http_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `http_path` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_permissions_name_unique` (`name`),
  UNIQUE KEY `admin_permissions_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_permissions` WRITE;
/*!40000 ALTER TABLE `admin_permissions` DISABLE KEYS */;
INSERT INTO `admin_permissions` VALUES (1,'All permission','*','','*',NULL,NULL),(2,'Dashboard','dashboard','GET','/',NULL,NULL),(3,'Login','auth.login','','/auth/login\r\n/auth/logout',NULL,NULL),(4,'User setting','auth.setting','GET,PUT','/auth/setting',NULL,NULL),(5,'Auth management','auth.management','','/auth/roles\r\n/auth/permissions\r\n/auth/menu\r\n/auth/logs',NULL,NULL),(7,'Admin helpers','ext.helpers','','/helpers/*','2020-11-20 13:55:45','2020-11-20 13:55:45'),(8,'Logs','ext.log-viewer','','/logs*','2020-11-20 13:56:02','2020-11-20 13:56:02'),(11,'Backup','ext.backup','','/backup*','2020-11-20 15:20:10','2020-11-20 15:20:10');
/*!40000 ALTER TABLE `admin_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_menu`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_menu` (
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_menu_role_id_menu_id_index` (`role_id`,`menu_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_menu` WRITE;
/*!40000 ALTER TABLE `admin_role_menu` DISABLE KEYS */;
INSERT INTO `admin_role_menu` VALUES (1,2,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_menu` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_permissions` (
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_permissions_role_id_permission_id_index` (`role_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_permissions` WRITE;
/*!40000 ALTER TABLE `admin_role_permissions` DISABLE KEYS */;
INSERT INTO `admin_role_permissions` VALUES (1,1,NULL,NULL),(2,11,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_role_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_role_users` (
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_role_users_role_id_user_id_index` (`role_id`,`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_role_users` WRITE;
/*!40000 ALTER TABLE `admin_role_users` DISABLE KEYS */;
INSERT INTO `admin_role_users` VALUES (1,1,NULL,NULL);
/*!40000 ALTER TABLE `admin_role_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_roles_name_unique` (`name`),
  UNIQUE KEY `admin_roles_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_roles` WRITE;
/*!40000 ALTER TABLE `admin_roles` DISABLE KEYS */;
INSERT INTO `admin_roles` VALUES (1,'Administrator','administrator','2020-11-20 13:24:48','2020-11-20 13:24:48'),(2,'backup','backup','2020-11-23 11:11:31','2020-11-23 11:11:31');
/*!40000 ALTER TABLE `admin_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_user_permissions` (
  `user_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `admin_user_permissions_user_id_permission_id_index` (`user_id`,`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_user_permissions` WRITE;
/*!40000 ALTER TABLE `admin_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `admin_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `admin_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin_users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(190) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admin_users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admin_users` WRITE;
/*!40000 ALTER TABLE `admin_users` DISABLE KEYS */;
INSERT INTO `admin_users` VALUES (1,'admin','$2y$10$uWjs/EjATf/LsevM2StTr.C..NzJ.gpGmpkevG8BTKckl0A1D1NXi','Administrator',NULL,'g4tsbgKYIJ9FUNpKytkqnsG4HlsVKWc86R6EStdzTfmr6SrdVFNqb6uFUznT','2020-11-20 13:24:48','2020-11-20 13:24:48');
/*!40000 ALTER TABLE `admin_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `building_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `building_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `building_informations` WRITE;
/*!40000 ALTER TABLE `building_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `building_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `department_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `department_informations` WRITE;
/*!40000 ALTER TABLE `department_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `department_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `designation_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `designation_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `designation_informations` WRITE;
/*!40000 ALTER TABLE `designation_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `designation_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `district_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `district_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `district_informations` WRITE;
/*!40000 ALTER TABLE `district_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `district_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci,
  `queue` text COLLATE utf8mb4_unicode_ci,
  `payload` text COLLATE utf8mb4_unicode_ci,
  `exception` text COLLATE utf8mb4_unicode_ci,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2016_01_04_173148_create_admin_tables',1),(4,'2019_08_19_000000_create_failed_jobs_table',1),(5,'2020_11_27_154230_create_project_informations_table',2),(6,'2020_11_27_154557_create_section_informations_table',3),(7,'2020_11_27_154735_create_department_informations_table',4);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `project_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `project_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `projecr_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `project_informations` WRITE;
/*!40000 ALTER TABLE `project_informations` DISABLE KEYS */;
INSERT INTO `project_informations` VALUES (1,'CRM','CRM project','badda','badda, dhaka','1','2020-11-27 10:13:16','2020-11-27 10:19:05',NULL),(2,'HRM','HRM project','Highway Homes – 2nd floor KA – 32/6 Shahjadpur, Pragoti Sharoni, Gulshan','Dhaka','2','2020-11-27 10:18:49','2020-11-27 10:18:49',NULL),(3,'Bangladesh Thai','Bangladesh Thai','Badda Dhaka','Banani Dhaka','1','2020-11-27 10:22:51','2020-11-27 10:22:51',NULL);
/*!40000 ALTER TABLE `project_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `religion_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `religion_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `religion_informations` WRITE;
/*!40000 ALTER TABLE `religion_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `religion_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `section_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `section_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `others_description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `section_informations` WRITE;
/*!40000 ALTER TABLE `section_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `section_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `shift_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `shift_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `shift_informations` WRITE;
/*!40000 ALTER TABLE `shift_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `shift_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `test_table`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_table` (
  `id` bigint(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(250) DEFAULT NULL,
  `column_name` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `deleted_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `test_table` WRITE;
/*!40000 ALTER TABLE `test_table` DISABLE KEYS */;
INSERT INTO `test_table` VALUES (1,'Talemul Islam','[{\"key\":\"sdf\",\"value\":\"ewr\"},{\"value\":\"ewr\"},{\"value\":\"ewt\",\"desc\":\"ewt\"}]','2020-11-20 22:04:59','2020-11-20 16:04:59','2020-11-20 22:04:59'),(2,'Bangla','[{\"key\":\"fds\",\"value\":\"sdf\",\"desc\":\"fds\"},{\"key\":\"sfd\",\"value\":\"dsf\",\"desc\":\"dsf\"}]','2020-11-20 22:05:51','2020-11-20 16:05:08',NULL),(3,'Talemul Islam','[{\"key\":\"fee\",\"value\":\"jnj\",\"desc\":\"jnjn\"},{\"value\":\"jnnj\",\"desc\":\"njn\"},{\"key\":\"jn\",\"value\":\"jn\",\"desc\":\"k,\"},{\"key\":\"m,\",\"value\":\"m,\",\"desc\":\"mm,\"}]','2020-11-20 16:11:03','2020-11-20 16:11:03',NULL),(4,NULL,'[{\"key\":\"532\",\"selectbox\":\"val\",\"value\":\"324\",\"desc\":\"32\"},{\"key\":\"325\",\"selectbox\":\"2\",\"value\":\"325\",\"desc\":\"352\"},{\"key\":\"325\",\"selectbox\":\"1\",\"value\":\"325\",\"desc\":\"325\"}]','2020-11-20 16:14:34','2020-11-20 16:14:34',NULL);
/*!40000 ALTER TABLE `test_table` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `unit_informations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `unit_informations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_descriptions` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `level` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `unit_informations` WRITE;
/*!40000 ALTER TABLE `unit_informations` DISABLE KEYS */;
/*!40000 ALTER TABLE `unit_informations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

