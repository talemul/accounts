<?php

use Illuminate\Routing\Router;

Admin::routes();

Route::group([
    'prefix'        => config('admin.route.prefix'),
    'namespace'     => config('admin.route.namespace'),
    'middleware'    => config('admin.route.middleware'),
    'as'            => config('admin.route.prefix') . '.',
], function (Router $router) {

    $router->get('/', 'HomeController@index')->name('home');
    $router->resource('test_table', TestTableController::class)->names('TestTableController');
    $router->resource('building_information', BuildingInformationController::class)->names('TestTableController');
    $router->resource('unit_information', UnitInformationController::class)->names('TestTableController');
    $router->resource('shift_information', ShiftInformationController::class)->names('TestTableController');
    $router->resource('section_information', SectionInformationController::class)->names('TestTableController');
    $router->resource('religion_information', ReligionInformationController::class)->names('TestTableController');
    $router->resource('district_information', DistrictInformationController::class)->names('TestTableController');
    $router->resource('designation_information', DesignationInformationController::class)->names('TestTableController');
    $router->resource('project_information', ProjectInformationController::class)->names('TestTableController');
    $router->resource('department_information', DepartmentInformationController::class)->names('TestTableController');



});
